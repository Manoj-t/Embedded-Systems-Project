<?php
include("globalsettings.php");

if ((isset($_REQUEST['msg'])) && (!empty($_REQUEST['msg'])))
{
    $msg = $_GET['msg'];
}else{
    $msg = 'Page Initializing';
}

$projectTitle = '::Embedded System Status Monitoring::';
$machName = "Test-Dock1";
$devName = "Port";

$empty = "empty.png";
$green = "gdevice.png";
$red = "rdevice.png";

$frameHtml = "";

$html = "<table>";
$html .= "<tr><td></td><td></td><td></td><td></td></tr>";

$loc = 8;
$port = 0;

$arra = array();

$undock = 0;
$dock = 0;
$fail = 0;

for ($i = 0; $i < $loc; $i++) {
    $port = ($i+1);

    $file_path = 'files/'.$port.'.txt';
    $fh = fopen($file_path,'r');

    $type = '';
    $date = '';
    $camera = '';

    $img = $empty;
    $status = 0;

    $j = 0;
    while ($line = fgets($fh)) {
    if($j == 0) {
        $type = $line;
        if(strtolower(trim($type)) == 'docked'){
            $dock++;
            $img = $green;
            $status = 1;
        }
        if(strtolower(trim($type)) == 'undocked'){
            $undock++;
            $img = $empty;
            $status = 0;
        }
        if(strtolower(trim($type)) == 'failed'){
            $fail++;
            $img = $red;
            $status = 2;
        }
    }

    if($j == 1) {
        $date = $line;
    }
    if($j == 2) {
        $camera = $line;
    }
    $j++;
    }
    fclose($fh);

    if ($i == 0) {
        $html .= "<tr>";
    }
    if ($i % 4 == 0) {
        $html .= "</tr><tr>";
    }

    $devInfo = "";
    $devStat = "";

    if ($status != 0) {
        if ($status == 1) {
            $devInfo = $camera;
            $devStat = "DOCKED";
            $arra[$i] = "send.php?sys=$machName&pno=$port&cam=$devInfo&status=$devStat";
        }
        if ($status == 2) {
            $devInfo = $camera;
            $devStat = "FAILED";
            $arra[$i] = "send.php?sys=$machName&pno=$port&cam=$devInfo&status=$devStat";
        }
    } else {
        $devStat = "NONE";
        $arra[$i] = "send.php?sys=$machName&pno=$port&cam=NONE&status=$devStat";
    }

    $html .= "<td><div class=\"container\"><img src='" . $img . "' title='' width='128' height='182' /><div class=\"centered\">" . $devInfo . "</div><div class=\"top-right\">" . $devStat . "</div></div><center>" . $devName . ($i + 1) . "</center></td>";
}
$html .= "</tr></table>";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title><?php echo $projectTitle ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="refresh" content="55;URL='index.php?msg=Page Refreshing'" />
        <link href="style.css" rel="stylesheet" type="text/css" />
        <!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
        <script type="text/javascript" src="js/cufon-yui.js"></script>
        <script type="text/javascript" src="js/arial.js"></script>
        <script type="text/javascript" src="js/cuf_run.js"></script>
        <!-- CuFon ends -->
        
        <script type="text/javascript" src="AjaxFramework.js"></script>

        <style>
            /* Container holding the image and the text */
            .container {
                position: relative;
                text-align: center;
                color: black;
            }

            /* Bottom left text */
            .bottom-left {
                position: absolute;
                bottom: 8px;
                left: 16px;
            }

            /* Top left text */
            .top-left {
                position: absolute;
                top: 8px;
                left: 16px;
            }

            /* Top right text */
            .top-right {
                position: absolute;
                top: 8px;
                right: 16px;
            }

            /* Bottom right text */
            .bottom-right {
                position: absolute;
                bottom: 8px;
                right: 16px;
            }

            /* Centered text */
            .centered {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }
        </style>
    </head>
    <body>
        <div id="info">           
        </div>
        <div class="main">

            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <ul>
                            <li class="active"><a href="index.php"><img src='c.png' width='32' height='32' title='configure'/>&nbsp;&nbsp;Configure</a></li>

                        </ul>
                        <div>
                            <h1>Notifications</h1>
                            <?php
                                echo $msg.". Last Updated On " . date("Y/m/d") . " @ ". date("h:i:sa") . "<br>";
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="content">
                <div class="content_resize">
                    <div class="mainbar">


                        <div class="article">
                            <?php echo $html ?>
                        </div>

                    </div>

                    <div class="sidebar">
                      <table class="table">
                          <tr>
                              <td>Docked Camera</td>
                              <td><?php echo $dock;?></td>
                          </tr>
                          <tr>
                              <td>Undocked Camera</td>
                              <td><?php echo $undock;?></td>
                          </tr>
                          <tr>
                              <td>Failed Camera</td>
                              <td><?php echo $fail;?></td>
                          </tr>
                      </table>
                      <br /><br />
                      <table class="table">
            	      <tr><th>Camera Info</th><th></th></tr>
                      <?php
                  		$lines = array('Total Number Of Docks','Total Number Of Failed Docks','Total Number Of Files','Total Files Size');
                  		$file_path = 'files/Summary.txt';
                          	$fh = fopen($file_path,'r');
                  		$i = 0;
                  		while ($line = fgets($fh)) {
                  		?>
                                <tr>
                                    <td><?php echo $lines[$i];?></td>
                                    <td><?php echo $line;?></td>
                                </tr>
                                <?php
                  		$i++;
                  		} ?>
                      </table>
                    </div>

                    <div class="clr">

                    </div>
                </div>

            </div>

            <div class="fbg">
                <div class="fbg_resize">
                  <?php
                  for ($i = 0; $i < $loc; $i++) {
                      echo "<iframe src='".$arra[$i]."' width='400' height='50'></iframe><br /><br />";
                  }
                  ?>
                </div>
            </div>

            <div>

            </div>
        </div>
        
        
        <script type="text/javascript">
            window.setInterval("refreshDiv()", 10000);
            function refreshDiv() {                
                getEmergenceDetailsES("info"); 
            }
        </script>
        
    </body>
</html>
