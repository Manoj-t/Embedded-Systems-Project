<?php

$flag = 0;
$loc = 8;
for ($i = 0; $i < $loc; $i++) {
    $port = ($i + 1);
    $file_path = 'files/' . $port . '.txt';
    $LastMod = filemtime($file_path);
    clearstatcache();
    if (($LastMod + 10) > time()) {
        //echo "file in use please wait... last modified : $LastMod";        
        $flag = 1;
        break;
    } else {        
        
    }
}

if($flag==1){
    echo "1";
}else{
    echo "0";
}

?>