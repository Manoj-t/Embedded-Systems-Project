<?php

$sys = $_GET["sys"];

$pno = $_GET["pno"];
$pno = (int)$pno;

$cam = $_GET["cam"];
$status = $_GET["status"];

if(strcmp($status,"FAILED")==0){
    $status = 6;
}
if(strcmp($status,"DOCKED")==0){
    $status = 1;
}
if(strcmp($status,"NONE")==0){
    $status = 0;
}


abstract class PORTSTATUS
{
    const NONE = 0;
    const DOCKED = 1;
    const DOCK_FAILED = 2;
    const DOCK_OK = 3;
    const TRANS = 4;
    const TRANS_COMPLETED = 5;
    const FAILED = 6;
    const PWR_ON = 7;
    const PWR = 8;
    const OFF = 9;
    const NO_NETWORK = 10;
    const NO_API = 11;
    const NO_SFTP = 12;
}

$url = "https://api02.visiologix.com/api/Docks/".$sys."/Port";


$portobject = array('PortNumber' => $pno, 'DateTime' => null, 'PortStatus' => $status, 'CameraSN' => $cam);
$data = json_encode($portobject);

//echo 'Encoded Json: ' . $data . '<br>';


$opts = array('http' =>
  array(
    'method'  => 'PUT',
    'header'  => 'Content-Type: application/json; charset=utf-8',
    'content' => $data, 
    'timeout' => 60
  )
);
                        
$context  = stream_context_create($opts);

$result = file_get_contents($url, false, $context);

if (FALSE === $result)
{
    echo 'HTTP request failed.' . '<br>';
}
else
{
	echo "Successfully Updated Port Status of PortNumber('".$pno."')!'";
}
//var_dump($http_response_header);


?>