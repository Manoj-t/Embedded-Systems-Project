<?php
include("globalsettings.php");

$projectTitle = '::Embedded System Status Monitoring::';

$json = file_get_contents("https://api02.visiologix.com/api/Docks/ActiveWithDetail");
$array = json_decode($json, true);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title><?php echo $projectTitle ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="refresh" content="59" />
        <link href="style.css" rel="stylesheet" type="text/css" />
        <!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
        <script type="text/javascript" src="js/cufon-yui.js"></script>
        <script type="text/javascript" src="js/arial.js"></script>
        <script type="text/javascript" src="js/cuf_run.js"></script>
        <!-- CuFon ends -->


        <script src="lib/jquery.min.js"></script>
        <script src="lib/materialize.min.js"></script>
        <link href="lib/materialize.min.css" rel="stylesheet"/>

        <style>
            /* Container holding the image and the text */
            .container {
                position: relative;
                text-align: center;
                color: black;
            }

            /* Bottom left text */
            .bottom-left {
                position: absolute;
                bottom: 8px;
                left: 16px;
            }

            /* Top left text */
            .top-left {
                position: absolute;
                top: 8px;
                left: 16px;
            }

            /* Top right text */
            .top-right {
                position: absolute;
                top: 8px;
                right: 16px;
            }

            /* Bottom right text */
            .bottom-right {
                position: absolute;
                bottom: 8px;
                right: 16px;
            }

            /* Centered text */
            .centered {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }
        </style>

    </head>
    <body>
        <div class="main">

            <div class="header">
                <div class="header_resize">
                    <div class="menu_nav">
                        <ul>
                            <li class="active"><a href="index.php"></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="content">
                <div class="content_resize">
                    <div class="mainbar">
                        <div>
                            <h4>IDS Status</h4>
                        </div>

                        <div class="article">

                            <div>
                                <ul class="collapsible" data-collapsible="accordion">
                                    <?php
                                    foreach ($array as $key => $value) {

                                        $flag = '<table><tr><td>Network Status </td></tr><tr><td><img src="red.png" /></td></tr></table>';
                                        if($value['isEnable']=='1'){
                                            $flag = '<table><tr><td>Network Status </td></tr><tr><td><img src="green.png" /></td></tr></table>';
                                        }
                                        
                                        $dp = '<table><caption>Ports Information</caption><tr><th>Port Number</th><th>Last Update Time</th><th>Port Status</th><th>Canera SN</th></tr>';
                                        foreach ($value['dockingPorts'] as $val) {
                                            $status = 'NONE';
                                            if($val['portStatus']=='0'){
                                                $status = 'NONE';
                                            }
                                            if($val['portStatus']=='1'){
                                                $status = 'DOCKED';
                                            }
                                            if($val['portStatus']=='6'){
                                                $status = 'FAILED';
                                            }
                                            $dp.= '<tr><td>'.$val['portNumber'] . '</td><td>' . $val['lastUpdateTime'] . '</td><td>' . $status . '</td><td>' . $val['cameraSN'] . '</td></tr>';
                                        }
                                        $dp .= '</table>';
                                        
                                        $history = '<table>';
                                        $port = 0;
                                        foreach ($value['stationHistories'] as $val) {
                                            $completedDocks = $val['completedDocks'];
                                            $failedDocks = $val['failedDocks'];
                                            $totalDocks = $val['totalDocks'];
                                            $totalFilesTransferred = $val['totalFilesTransferred'];
                                            $totalFilesSize = $val['totalFilesSize'];
                                            
                                            $history.= '<tr><td>Completed Docks : '.$completedDocks.'</td></tr>';
                                            $history.= '<tr><td>Failed Docks : '.$failedDocks.'</td></tr>';
                                            $history.= '<tr><td>Total Docks : '.$totalDocks.'</td></tr>';
                                            $history.= '<tr><td>Total Files Transferred : '.$totalFilesTransferred.'</td></tr>';
                                            $history.= '<tr><td>Total Files Size : '.$totalFilesSize.'</td></tr>';
                                        }
                                        $history .= '</table>';
                                        
                                        ?>

                                        <li>
                                            <div class="collapsible-header"><?php echo $value['machineID']; ?></div>
                                            <div class="collapsible-body">
                                                <?php echo $flag; ?>
                                                <?php echo $history; ?>
                                                <?php echo $dp; ?>
                                            </div>
                                        </li>
                                    <?php } ?>

                                </ul>
                            </div>            


                        </div>

                    </div>

                    <div class="sidebar">                      
                    </div>

                    <div class="clr">

                    </div>
                </div>

            </div>

            <div class="fbg">
                <div class="fbg_resize">

                </div>
            </div>

            <div>

            </div>
        </div>
    </body>
</html>
